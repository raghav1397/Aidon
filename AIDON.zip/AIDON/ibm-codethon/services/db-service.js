var MongoClient = require('mongodb').MongoClient;

var getMongoClient = new Promise((resolve, reject) => {
        MongoClient.connect("mongodb://localhost:27017", { useNewUrlParser: true, useUnifiedTopology: true}).then(client => {
            resolve(client)
        }, err => {
            console.log(err);
            reject(err);
        });
    })    

var getConnection = function getConnection(databaseName) {
    return new Promise((resolve, reject) => {
        getMongoClient.then((client) => {
            var db = client.db(databaseName)
            resolve(db);
        }, err => {
            console.log(err)
        })
    }) 
}

exports.getConnection = getConnection 

