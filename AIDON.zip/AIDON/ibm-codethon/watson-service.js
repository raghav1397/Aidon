const watson = require('ibm-watson/assistant/v2');

assistant = AssistantV2(
    version='v1',
    iam_apikey='{apikey}',
    url='{url}'
)

exports.getMessage = body =>
  new Promise((resolve, reject) => {
    assistant.message(
      {
        workspace_id: process.env.WATSON_WORKSPACE_ID,
        input: { text: body.input }
      },
      function(err, response) {
        if (err) {
          console.log(err);
          reject(err);
        } else {
          resolve(response);
        }
      }
    );
  });