const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = 3000

app.use(bodyParser.json())
app.use(express.urlencoded({ extended: true }))

app.get('/', (req, res) => res.send('Hello World!'))
var MongoClient = require('mongodb').MongoClient;
var getConnection = require('./services/db-service').getConnection

app.get('/GetDonors', (req, res) => {

    console.log(req.query.city);

    // Connect to the db
    
    getConnection('codeathon').then(db => {
        var collection = db.collection('donors')
        cursor = collection.find({})
        var data = [];
        cursor.forEach(element => {
            data.add(element);
            console.log(element);
        });
        res.send({donordata : data})
    });
});

app.post('/SaveDonorInfo', (req, res) => {
    getConnection('codeathon').then(db => {
        var collection = db.collection('donors')
        collection.insertOne(req.body).then( () => {
            res.send("200 OK")
        }, err=> {
            res.send("500 internal server error")
        })
    })
})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))
